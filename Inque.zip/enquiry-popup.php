  <div class="modal fade" id="enquiryForm" role="dialog">
      <div class="modal-dialog modal-sm">
          <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Request for pdf</h4>
          </div>
          <div class="modal-body">
            <form>
                <input type="text" name="" placeholder="Name">
                <input type="email" name="" placeholder="Email ID">
                <input type="text" name="" placeholder="Phone">
                <input type="text" name="" placeholder="Company">
                <input type="text" name="" placeholder="Country">
                <input type="text" name="" placeholder="State">
                <input type="text" name="" placeholder="City">
                <button class="submit pull-left">Submit</button>
            </form>
          </div>
          <div class="clear15"></div>
          </div>
      </div>
  </div>