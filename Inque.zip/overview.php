<?php 
$pgTitle = "INQUE - Modular kitchen and bathroom accessories";
include_once('header.php') ?>

            <div class="container-fluid banner margin-top100">
                <img src="assets/images/top-banner.jpg" class="responsive-img">
                <h6>solution for smart spaces</h6>
            </div>
            <div class="clear0"></div>
            <div class="container weare">
                <div class="col-sm-6">
                    <div class="">
                        <h5>We are</h5>
                        <p>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum, has been theindustry's standard dummy text ever since the1500s, when an unknown Printer took a galley of type and scrambled it tomake a type specimen book. It has survived not only five centuries, but alsothe leap into electronic typesetting, remaining essentially unchanged.</p>
                            <p>
                            It was popularised in the 1960s with the release of Letraset sheets containingLorem Ipsum passages, and more recently with desktop publishing software

                            like Aldus PageMaker including versions of Lorem Ipsum. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing softwarelike Aldus PageMaker including versions of Lorem Ipsum.
                        </p>
                    </div>
                </div>
                <div class="col-sm-6 pl0">
                    <div class="img-black">
                      
                   </div>
                </div>
            </div>
            <div class="container-fluid pl0 vision-mission">
                <div class="">
                   <img src="assets/images/aboutus/mission-vision-bg.jpg" class="responsive-img">
                   <div class="container">
                       <h5 class="white">OUR MISSION</h5>
                       <p>
                            like Aldus PageMaker including versions of Lorem Ipsum. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing softwarelike Aldus PageMaker including versions of Lorem Ipsum.
                       </p>
                       <h5 class="white">OUR VISION</h5>
                       <p>
                            like Aldus PageMaker including versions of Lorem Ipsum. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing softwarelike Aldus PageMaker including versions of Lorem Ipsum.
                       </p>
                   </div>
               </div>
            </div>
            <div class="clear15"></div>
            <div class="container distributor ">
                <h5>FIND DISTRIBUTOR</h5>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum, has been theindustry's standard dummy text ever since the1500s, when an unknown Printer took a galley of type and scrambled it tomake a type specimen book. It has survived not only five centuries, but alsothe leap into electronic typesetting, remaining essentially unchanged.</p>
            </div>
            <div class="container find-contact">
                <ul>
                    <li class="">
                        <div>
                            <p>Contact details for distributor </p>
                            <form>
                                <input type="text" name="country" placeholder="Country">
                                <input type="text" name="state" placeholder="State">
                                <input type="text" name="City" placeholder="City">
                                <input type="button" name="submit"  value="SUBMIT" />
                            </form>
                        </div>
                    </li>
                    <li>
                        <div>
                            <p>
                                <b>Ghatkopar - Mumbai</b>
                                <span>904, Peninsula Tower 1,</span>
                                <span>Ganrao Kadam Marg</span>
                                <span>Mumbai - 400013</span>
                            </p>
                            <p>
                                <span>Tel: +91-22-2852 0329</span>
                                <span>Tel: +91-22-2852 0329</span>
                            </p>
                            <p>
                                <span>Email: design@inque.co.in</span>
                                <span>Email: sales.design@inque.co.in</span>
                            </p>

                        </div>

                        <div>
                            <p>
                                <b>Ghatkopar - Mumbai</b>
                                <span>904, Peninsula Tower 1,</span>
                                <span>Ganrao Kadam Marg</span>
                                <span>Mumbai - 400013</span>
                            </p>
                            <p>
                                <span>Tel: +91-22-2852 0329</span>
                                <span>Tel: +91-22-2852 0329</span>
                            </p>
                            <p>
                                <span>Email: design@inque.co.in</span>
                                <span>Email: sales.design@inque.co.in</span>
                            </p>
                        </div>                    
                    </li>
                    <li>
                        <div>
                            <p>
                                <b>Ghatkopar - Mumbai</b>
                                <span>904, Peninsula Tower 1,</span>
                                <span>Ganrao Kadam Marg</span>
                                <span>Mumbai - 400013</span>
                            </p>
                            <p>
                                <span>Tel: +91-22-2852 0329</span>
                                <span>Tel: +91-22-2852 0329</span>
                            </p>
                            <p>
                                <span>Email: design@inque.co.in</span>
                                <span>Email: sales.design@inque.co.in</span>
                            </p>
                        </div>
                        <div>
                            <p>
                                <b>Ghatkopar - Mumbai</b>
                                <span>904, Peninsula Tower 1,</span>
                                <span>Ganrao Kadam Marg</span>
                                <span>Mumbai - 400013</span>
                            </p>
                            <p>
                                <span>Tel: +91-22-2852 0329</span>
                                <span>Tel: +91-22-2852 0329</span>
                            </p>
                            <p>
                                <span>Email: design@inque.co.in</span>
                                <span>Email: sales.design@inque.co.in</span>
                            </p>
                        </div>
                    </li>
                    
                    <li>
                        <div>
                            <p>
                                <b>Ghatkopar - Mumbai</b>
                                <span>904, Peninsula Tower 1,</span>
                                <span>Ganrao Kadam Marg</span>
                                <span>Mumbai - 400013</span>
                            </p>
                            <p>
                                <span>Tel: +91-22-2852 0329</span>
                                <span>Tel: +91-22-2852 0329</span>
                            </p>
                            <p>
                                <span>Email: design@inque.co.in</span>
                                <span>Email: sales.design@inque.co.in</span>
                            </p>

                        </div>
                    </li>
                </ul>
            </div>
            <div class="container-fluid footer">
                <div class="clear0"></div>
                <?php include_once('footer.php') ?>
            </div>
        </div>

        <div class="clear0"></div>

        <!-- <script src="assets/js/bootstrap.min.js"></script> -->
        <script src="assets/gallery/js/masonry.pkgd.min.js"></script>
        <script src="assets/gallery/js/imagesloaded.js"></script>
        <script src="assets/gallery/js/classie.js"></script>
        <script src="assets/gallery/js/AnimOnScroll.js"></script>

       <!--  <script type="text/javascript">
            $(".menubar").on('click', 'li', function () {
                $(".menubar li.active").removeClass("active");
                $(this).addClass("active");
            });
        </script>
        <script>
            new AnimOnScroll( document.getElementById( 'grid1' ), {
                minDuration : 0.4,
                maxDuration : 0.7,
                viewportFactor : 0.2
            } );
        </script> -->
    </body>
</html>
