<?php
$this->beginContent('//layouts/loginContainer');
echo $content;
$this->endContent();
?>