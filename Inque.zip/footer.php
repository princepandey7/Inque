<script type='text/javascript'>
    $(window).load(function(){
        $('#loader-overlay').fadeOut(900);
        $("html").css("overflow","visible");
    });
    </script>
 <footer>
    <img src="assets/images/footer-logo.png">
    <div class="clear0"></div>
    <div class="container">
        <hr/>
        <div class="clear0"></div>
        <div class="col-sm-8 pl0">
            <p>All Rights Reserved &copy;&nbsp; | <a href="">Contact</a>
        | <a href="">Privacy Policy</a> | &nbsp;Site Credit <a href="">M9 Creative</a></p>
        </div>
        <div class="col-sm-4 pr0 social">
            <a href=""><img src="assets/images/fb.png"></a>
            <a href=""><img src="assets/images/tw.png"></a>
        </div>
    </div>
</footer>
 <script type="text/javascript">
    $(".menubar").on('click', 'li', function () {
        $(".menubar li.active").removeClass("active");
        $(this).addClass("active");
    });
</script>